from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("wiki/<str:title>", views.entry_page, name="entry"),
    path("search", views.search, name="search"),
    path("CriarPagina", views.CriarPagina, name="CriarPagina"),
    path("SalvarPagina", views.SalvarPagina, name="SalvarPagina"),
    path("EditarPagina/<str:title>", views.EditarPagina, name="EditarPagina"),
    path("SalvarPagina/<str:title>", views.SalvarPagina, name="SalvarPagina1"),
    path("RandomPage/", views.randomPage, name="RandomPage")
]
