import re
import random

from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
import markdown2
from . import util

wiki_entries_directory = "entries/"


def index(request):
    return render(request, "encyclopedia/index.html", {
        "entries": util.list_entries(),
        "title": "Home",
        "heading": "Paginas Disponiveis"
    })


def EditarPagina(request, title):
    entry_contents = util.get_entry(title)
    if entry_contents is None:
        return HttpResponseRedirect(reverse("index"))

    return render(request, "encyclopedia/CriarPagina.html", {
        'edit_mode': True,
        'edit_page_title': title,
        'edit_page_contents': entry_contents
    })

def search(request):
    query = request.GET['q']
    if util.get_entry(query):
        return HttpResponseRedirect(reverse("entry", args=(query,)))
    else:
        return render(request, "encyclopedia/index.html", {
            "entries": [entry for entry in util.list_entries() if query.lower() in entry.lower()],
            "title": f'"{query}" Procura',
            "heading": f'Resultados da pesquisa "{query}"'
        })


def entry_page(request, title):
    entry_contents = util.get_entry(title)
    html_entry_contents = markdown2.markdown(entry_contents) if entry_contents else None

    return render(request, "encyclopedia/entry.html", {
        "body_content": html_entry_contents,
        "entry_exists": entry_contents is not None,
        "title": title if entry_contents is not None else "Error"
    })





def CriarPagina(request):
    return render(request, "encyclopedia/CriarPagina.html", {
        'edit_mode': False,
        'edit_page_title': '',
        'edit_page_contents': ''
    })


def SalvarPagina(request, title=None):
    if request.method == 'GET':
        return HttpResponseRedirect(reverse("index"))
    else:
        assert (request.method == 'POST')
        entry_content = request.POST['entry-content']
        if not title:
            title = request.POST['title']
            if title.lower() in [entry.lower() for entry in util.list_entries()]:
                return render(request, "encyclopedia/erro.html", {
                    "error_title": "Salvando Pagina",
                    "error_message": "Uma pagina com mesmo titulo ja existe! Mude o titulo."
                })

        filename = wiki_entries_directory + title + ".md"
        with open(filename, "w") as f:
            f.write(entry_content)
        return HttpResponseRedirect(reverse("entry", args=(title,)))




def randomPage(request):
    entry_title = random.choice(util.list_entries())
    return HttpResponseRedirect(reverse("entry", args=(entry_title,)))